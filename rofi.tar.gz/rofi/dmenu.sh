bindsym $mod+d exec rofi -modi drun -show drun -config .config/rofi/dmenu.rasi
