~/.config/i3/scripts/shutdown_menu rofi -config '/home/joe/.config/rofi/powermenu.rasi'
